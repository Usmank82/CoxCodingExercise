﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            ////Answer to Question 1: Palindrome.
            string input = "madam";
            bool isPal = IsPalingdrome(input);
            Console.WriteLine("Is " + input + " palindrome?");
            Console.WriteLine(isPal == true ? "The answer is: YES" : "The answer is: NO");
            //Console.ReadLine();


            //Answer to Question 2: Keycount
            var counter = new List<KeyValuePair<string, int>>();
            counter.Add(new KeyValuePair<string, int>("Usman", 10));
            counter.Add(new KeyValuePair<string, int>("Salman", 7));
            counter.Add(new KeyValuePair<string, int>("Marina", 12));
            counter.Add(new KeyValuePair<string, int>("Usman", 15));
            counter.Add(new KeyValuePair<string, int>("Salman", 3));
            counter.Add(new KeyValuePair<string, int>("Marina", 8));
            var output = counter.GroupBy(x => x.Key)
                .Select(g => new KeyValuePair<string, int>(g.Key, g.Sum(x => x.Value)));
            Console.WriteLine("Key Count");
            foreach (var item in output)
            {
                Console.WriteLine(string.Format("{0}, {1}", item.Key.ToString(), item.Value.ToString()));
            }
            Console.ReadLine();
        }
        static bool IsPalingdrome(string input)
        {
            input = input.ToLower();
            int count = input.Length;
            if (count == 0)
            {
                return true;
            }
            return IsPalingdrome(input, 0, count - 1);
        }
        static bool IsPalingdrome(string input, int start, int end)
        {
            if (start == end)
            {
                return true;
            }
            if (input[start] != input[end])
            {
                return false;
            }
            if (start < end + 1)
            {
                return IsPalingdrome(input, start + 1, end - 1);
            }
            return true;
        }
    }

}
